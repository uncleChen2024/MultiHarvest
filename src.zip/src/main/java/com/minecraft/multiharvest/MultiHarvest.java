package com.minecraft.multiharvest;

import com.minecraft.multiharvest.command.MultiHarvestCommand;
import com.minecraft.multiharvest.config.ConfigManager;
import com.minecraft.multiharvest.gui.GuiManager;
import com.minecraft.multiharvest.listener.BlockBreakListener;
import com.minecraft.multiharvest.listener.GuiClickListener;
import com.minecraft.multiharvest.listener.PlayerActivityListener;
import com.minecraft.multiharvest.util.CooldownUtils;
import com.minecraft.multiharvest.util.DurabilityManager;
import com.minecraft.multiharvest.util.LanguageManager;
import com.minecraft.multiharvest.util.NotificationManager;
import com.minecraft.multiharvest.util.StatisticsManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class MultiHarvest extends JavaPlugin {
    
    private static MultiHarvest instance;
    private ConfigManager configManager;
    private GuiManager guiManager;
    private CooldownUtils cooldownUtils;
    private LanguageManager languageManager;
    private StatisticsManager statisticsManager;
    private DurabilityManager durabilityManager;
    private NotificationManager notificationManager;

    @Override
    public void onEnable() {
        // 保存插件实例
        instance = this;
        
        // 保存默认配置
        saveDefaultConfig();
        
        // 初始化语言管理器
        languageManager = new LanguageManager(this);
        
        // 初始化配置管理器
        configManager = new ConfigManager(this);
        configManager.loadConfig();
        
        // 初始化冷却工具
        cooldownUtils = new CooldownUtils(this);
        
        // 初始化耐久度管理器
        durabilityManager = new DurabilityManager(this);
        
        // 初始化统计管理器
        statisticsManager = new StatisticsManager(this);
        
        // 初始化通知管理器
        notificationManager = new NotificationManager(this);
        
        // 初始化GUI管理器
        guiManager = new GuiManager(this);
        
        // 注册事件监听器
        getServer().getPluginManager().registerEvents(new BlockBreakListener(this), this);
        getServer().getPluginManager().registerEvents(new GuiClickListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerActivityListener(this), this);
        
        // 注册命令
        getCommand("multiharvest").setExecutor(new MultiHarvestCommand(this));
        
        // 设置统计数据自动保存任务
        if (getConfig().getBoolean("statistics.auto_save", true)) {
            int saveInterval = getConfig().getInt("statistics.save_interval", 300) * 20; // 转换为tick
            getServer().getScheduler().runTaskTimer(this, () -> {
                statisticsManager.saveAllStats();
                getLogger().info("已自动保存玩家统计数据");
            }, saveInterval, saveInterval);
        }
        
        getLogger().info("MultiHarvest 插件已成功启用！");
    }

    @Override
    public void onDisable() {
        // 保存配置
        configManager.saveConfig();
        
        // 保存统计数据
        if (statisticsManager != null) {
            statisticsManager.saveAllStats();
        }
        
        // 保存玩家语言设置
        if (languageManager != null) {
            languageManager.savePlayerLanguageSettings();
        }
        
        getLogger().info("MultiHarvest 插件已禁用！");
    }
    
    public static MultiHarvest getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public GuiManager getGuiManager() {
        return guiManager;
    }
    
    public CooldownUtils getCooldownUtils() {
        return cooldownUtils;
    }
    
    public LanguageManager getLanguageManager() {
        return languageManager;
    }
    
    public StatisticsManager getStatisticsManager() {
        return statisticsManager;
    }
    
    public DurabilityManager getDurabilityManager() {
        return durabilityManager;
    }
    
    public NotificationManager getNotificationManager() {
        return notificationManager;
    }
}