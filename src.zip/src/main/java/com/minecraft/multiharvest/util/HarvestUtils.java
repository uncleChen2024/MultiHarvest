package com.minecraft.multiharvest.util;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

import java.util.*;

public class HarvestUtils {
    
    private final MultiHarvest plugin;
    
    public HarvestUtils(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 检查物品是否为斧子
     * @param item 物品
     * @return 是否为斧子
     */
    private boolean isAxe(ItemStack item) {
        if (item == null) return false;
        
        Material type = item.getType();
        return type == Material.WOODEN_AXE || 
               type == Material.STONE_AXE || 
               type == Material.IRON_AXE || 
               type == Material.GOLDEN_AXE || 
               type == Material.DIAMOND_AXE ||
               type == Material.NETHERITE_AXE;
    }
    
    /**
     * 检查物品是否为镐子
     * @param item 物品
     * @return 是否为镐子
     */
    private boolean isPickaxe(ItemStack item) {
        if (item == null) return false;
        
        Material type = item.getType();
        return type == Material.WOODEN_PICKAXE || 
               type == Material.STONE_PICKAXE || 
               type == Material.IRON_PICKAXE || 
               type == Material.GOLDEN_PICKAXE || 
               type == Material.DIAMOND_PICKAXE ||
               type == Material.NETHERITE_PICKAXE;
    }
    
    /**
     * 检查是否为树的底部方块
     * @param block 方块
     * @return 是否为底部方块
     */
    private boolean isBottomTreeBlock(Block block) {
        // 检查下方方块是否为树木方块
        Block blockBelow = block.getRelative(0, -1, 0);
        return !plugin.getConfigManager().getTreeBlocks().contains(blockBelow.getType());
    }
    
    /**
     * 处理自动砍树逻辑
     * @param player 玩家
     * @param block 被破坏的方块
     * @return 被破坏的方块数量
     */
    public int handleTreeChop(Player player, Block block) {
        // 检查是否为树木方块
        if (!plugin.getConfigManager().getTreeBlocks().contains(block.getType())) {
            return 0;
        }
        
        // 获取玩家手中的物品
        ItemStack handItem = player.getInventory().getItemInMainHand();
        
        // 检查是否需要斧子
        if (plugin.getConfigManager().isRequireAxeForTreeChop() && !isAxe(handItem)) {
            return 0;
        }
        
        // 检查是否必须从底部开始砍
        if (plugin.getConfigManager().isMustChopBottom() && !isBottomTreeBlock(block)) {
            return 0;
        }
        
        // 检查工具耐久度
        if (handItem.getType().getMaxDurability() > 0) {
            ItemMeta meta = handItem.getItemMeta();
            if (meta instanceof Damageable) {
                Damageable damageable = (Damageable) meta;
                if (damageable.getDamage() >= handItem.getType().getMaxDurability()) {
                    return 0;
                }
            }
        }
        
        // 使用BFS算法查找相连的树木方块
        Set<Block> treeBlocks = new HashSet<>();
        Set<Block> leafBlocks = new HashSet<>();
        Queue<Block> queue = new LinkedList<>();
        Set<Block> visited = new HashSet<>();
        
        queue.add(block);
        visited.add(block);
        
        int maxBlocks = plugin.getConfigManager().getMaxTreeBlocks();
        Set<Material> treeBlockTypes = plugin.getConfigManager().getTreeBlocks();
        Set<Material> leafBlockTypes = plugin.getConfigManager().getLeafBlocks();
        
        while (!queue.isEmpty() && treeBlocks.size() < maxBlocks) {
            Block current = queue.poll();
            
            if (treeBlockTypes.contains(current.getType())) {
                treeBlocks.add(current);
                
                // 检查相邻方块（包括对角线方向，以支持金合欢树等带分支的树）
                for (int x = -1; x <= 1; x++) {
                    for (int y = -1; y <= 1; y++) {
                        for (int z = -1; z <= 1; z++) {
                            // 跳过自身
                            if (x == 0 && y == 0 && z == 0) continue;
                            
                            Block adjacent = current.getRelative(x, y, z);
                            
                            if (!visited.contains(adjacent)) {
                                visited.add(adjacent);
                                
                                // 如果是树木方块，加入队列继续搜索
                                if (treeBlockTypes.contains(adjacent.getType())) {
                                    queue.add(adjacent);
                                }
                                // 如果是树叶方块且需要清理树叶，记录下来
                                else if (plugin.getConfigManager().isClearLeaves() && 
                                         leafBlockTypes.contains(adjacent.getType())) {
                                    leafBlocks.add(adjacent);
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // 移除原始方块，因为它会被正常破坏
        treeBlocks.remove(block);
        
        // 记录原始方块位置，用于收集掉落物
        Location originLocation = block.getLocation().add(0.5, 0.5, 0.5);
        List<Item> droppedItems = new ArrayList<>();
        
        // 破坏树木方块
        for (Block treeBlock : treeBlocks) {
            // 获取方块的掉落物并破坏方块
            Collection<ItemStack> drops = treeBlock.getDrops(handItem);
            treeBlock.breakNaturally(handItem);
            
            // 如果需要收集掉落物，记录周围的掉落物实体
            if (plugin.getConfigManager().isCollectTreeDrops()) {
                // 获取方块周围5格范围内的所有掉落物实体
                treeBlock.getWorld().getNearbyEntities(treeBlock.getLocation().add(0.5, 0.5, 0.5), 2, 2, 2).forEach(entity -> {
                    if (entity instanceof Item) {
                        droppedItems.add((Item) entity);
                    }
                });
            }
        }
        
        // 如果需要清理树叶
        if (plugin.getConfigManager().isClearLeaves() && !leafBlocks.isEmpty()) {
            for (Block leafBlock : leafBlocks) {
                // 获取方块的掉落物并破坏方块
                Collection<ItemStack> drops = leafBlock.getDrops(handItem);
                leafBlock.breakNaturally(handItem);
                
                // 如果需要收集掉落物，记录周围的掉落物实体
                if (plugin.getConfigManager().isCollectTreeDrops()) {
                    // 获取方块周围5格范围内的所有掉落物实体
                    leafBlock.getWorld().getNearbyEntities(leafBlock.getLocation().add(0.5, 0.5, 0.5), 2, 2, 2).forEach(entity -> {
                        if (entity instanceof Item) {
                            droppedItems.add((Item) entity);
                        }
                    });
                }
            }
        }
        
        // 如果需要收集掉落物，将所有掉落物移动到原始方块位置
        if (plugin.getConfigManager().isCollectTreeDrops() && !droppedItems.isEmpty()) {
            for (Item item : droppedItems) {
                // 计算从当前位置到原始位置的向量
                Vector velocity = originLocation.toVector().subtract(item.getLocation().toVector());
                // 设置物品的速度，使其向原始位置移动
                item.setVelocity(velocity.normalize().multiply(0.2));
            }
        }
        
        return treeBlocks.size() + (plugin.getConfigManager().isClearLeaves() ? leafBlocks.size() : 0);
    }
    
    /**
     * 处理连锁挖矿逻辑
     * @param player 玩家
     * @param block 被破坏的方块
     * @return 被破坏的方块数量
     */
    public int handleChainMine(Player player, Block block) {
        // 检查是否为矿石方块
        if (!plugin.getConfigManager().getOreBlocks().contains(block.getType())) {
            return 0;
        }
        
        // 获取玩家手中的物品
        ItemStack handItem = player.getInventory().getItemInMainHand();
        
        // 检查是否需要镐子
        if (plugin.getConfigManager().isRequirePickaxeForChainMine() && !isPickaxe(handItem)) {
            return 0;
        }
        
        // 检查工具耐久度
        if (handItem.getType().getMaxDurability() > 0) {
            ItemMeta meta = handItem.getItemMeta();
            if (meta instanceof Damageable) {
                Damageable damageable = (Damageable) meta;
                if (damageable.getDamage() >= handItem.getType().getMaxDurability()) {
                    return 0;
                }
            }
        }
        
        // 使用BFS算法查找相连的矿石方块
        Set<Block> oreBlocks = new HashSet<>();
        Queue<Block> queue = new LinkedList<>();
        Set<Block> visited = new HashSet<>();
        
        Material targetType = block.getType();
        queue.add(block);
        visited.add(block);
        
        int maxBlocks = plugin.getConfigManager().getMaxOreBlocks();
        
        while (!queue.isEmpty() && oreBlocks.size() < maxBlocks) {
            Block current = queue.poll();
            
            if (current.getType() == targetType) {
                oreBlocks.add(current);
                
                // 检查相邻方块
                for (int x = -1; x <= 1; x++) {
                    for (int y = -1; y <= 1; y++) {
                        for (int z = -1; z <= 1; z++) {
                            // 跳过对角线方块，只检查直接相邻的方块
                            if (Math.abs(x) + Math.abs(y) + Math.abs(z) > 1) continue;
                            
                            Block adjacent = current.getRelative(x, y, z);
                            
                            if (!visited.contains(adjacent) && adjacent.getType() == targetType) {
                                queue.add(adjacent);
                                visited.add(adjacent);
                            }
                        }
                    }
                }
            }
        }
        
        // 移除原始方块，因为它会被正常破坏
        oreBlocks.remove(block);
        
        // 记录原始方块位置，用于收集掉落物
        Location originLocation = block.getLocation().add(0.5, 0.5, 0.5);
        List<Item> droppedItems = new ArrayList<>();
        
        // 破坏矿石方块
        for (Block oreBlock : oreBlocks) {
            // 破坏方块并自然掉落物品
            oreBlock.breakNaturally(handItem);
            
            // 如果需要收集掉落物，记录周围的掉落物实体
            if (plugin.getConfigManager().isCollectOreDrops()) {
                // 获取方块周围5格范围内的所有掉落物实体
                oreBlock.getWorld().getNearbyEntities(oreBlock.getLocation().add(0.5, 0.5, 0.5), 2, 2, 2).forEach(entity -> {
                    if (entity instanceof Item) {
                        droppedItems.add((Item) entity);
                    }
                });
            }
        }
        
        // 如果需要收集掉落物，将所有掉落物移动到原始方块位置
        if (plugin.getConfigManager().isCollectOreDrops() && !droppedItems.isEmpty()) {
            for (Item item : droppedItems) {
                // 计算从当前位置到原始位置的向量
                Vector velocity = originLocation.toVector().subtract(item.getLocation().toVector());
                // 设置物品的速度，使其向原始位置移动
                item.setVelocity(velocity.normalize().multiply(0.2));
            }
        }
        
        return oreBlocks.size();
    }
}