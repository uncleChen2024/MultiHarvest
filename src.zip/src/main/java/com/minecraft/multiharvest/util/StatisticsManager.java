package com.minecraft.multiharvest.util;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StatisticsManager {
    
    private final MultiHarvest plugin;
    private final Map<UUID, PlayerStats> playerStatsMap = new HashMap<>();
    
    public StatisticsManager(MultiHarvest plugin) {
        this.plugin = plugin;
        loadAllStats();
    }
    
    /**
     * 加载所有玩家的统计数据
     */
    public void loadAllStats() {
        File statsDir = new File(plugin.getDataFolder(), "stats");
        if (!statsDir.exists()) {
            statsDir.mkdirs();
            return;
        }
        
        File[] statsFiles = statsDir.listFiles((dir, name) -> name.endsWith(".yml"));
        if (statsFiles == null) return;
        
        for (File file : statsFiles) {
            String fileName = file.getName();
            String uuidString = fileName.substring(0, fileName.length() - 4); // 移除 .yml
            
            try {
                UUID uuid = UUID.fromString(uuidString);
                FileConfiguration statsConfig = YamlConfiguration.loadConfiguration(file);
                
                PlayerStats stats = new PlayerStats(uuid);
                stats.treeBlocksBroken = statsConfig.getInt("tree_blocks_broken", 0);
                stats.oreBlocksBroken = statsConfig.getInt("ore_blocks_broken", 0);
                
                // 加载方块类型统计
                if (statsConfig.contains("tree_blocks_by_type")) {
                    for (String materialName : statsConfig.getConfigurationSection("tree_blocks_by_type").getKeys(false)) {
                        try {
                            Material material = Material.valueOf(materialName);
                            int count = statsConfig.getInt("tree_blocks_by_type." + materialName, 0);
                            stats.treeBlocksByType.put(material, count);
                        } catch (IllegalArgumentException e) {
                            plugin.getLogger().warning("无效的材料名称: " + materialName);
                        }
                    }
                }
                
                if (statsConfig.contains("ore_blocks_by_type")) {
                    for (String materialName : statsConfig.getConfigurationSection("ore_blocks_by_type").getKeys(false)) {
                        try {
                            Material material = Material.valueOf(materialName);
                            int count = statsConfig.getInt("ore_blocks_by_type." + materialName, 0);
                            stats.oreBlocksByType.put(material, count);
                        } catch (IllegalArgumentException e) {
                            plugin.getLogger().warning("无效的材料名称: " + materialName);
                        }
                    }
                }
                
                playerStatsMap.put(uuid, stats);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("无效的玩家UUID: " + uuidString);
            }
        }
        
        plugin.getLogger().info("已加载 " + playerStatsMap.size() + " 个玩家的统计数据");
    }
    
    /**
     * 保存所有玩家的统计数据
     */
    public void saveAllStats() {
        for (Map.Entry<UUID, PlayerStats> entry : playerStatsMap.entrySet()) {
            savePlayerStats(entry.getKey());
        }
    }
    
    /**
     * 保存指定玩家的统计数据
     * @param uuid 玩家UUID
     */
    public void savePlayerStats(UUID uuid) {
        PlayerStats stats = playerStatsMap.get(uuid);
        if (stats == null) return;
        
        File statsDir = new File(plugin.getDataFolder(), "stats");
        if (!statsDir.exists()) {
            statsDir.mkdirs();
        }
        
        File statsFile = new File(statsDir, uuid.toString() + ".yml");
        FileConfiguration statsConfig = YamlConfiguration.loadConfiguration(statsFile);
        
        statsConfig.set("tree_blocks_broken", stats.treeBlocksBroken);
        statsConfig.set("ore_blocks_broken", stats.oreBlocksBroken);
        
        // 保存方块类型统计
        for (Map.Entry<Material, Integer> entry : stats.treeBlocksByType.entrySet()) {
            statsConfig.set("tree_blocks_by_type." + entry.getKey().name(), entry.getValue());
        }
        
        for (Map.Entry<Material, Integer> entry : stats.oreBlocksByType.entrySet()) {
            statsConfig.set("ore_blocks_by_type." + entry.getKey().name(), entry.getValue());
        }
        
        try {
            statsConfig.save(statsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("无法保存玩家统计数据: " + uuid);
            e.printStackTrace();
        }
    }
    
    /**
     * 获取玩家的统计数据
     * @param player 玩家
     * @return 统计数据
     */
    public PlayerStats getPlayerStats(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerStats stats = playerStatsMap.get(uuid);
        
        if (stats == null) {
            stats = new PlayerStats(uuid);
            playerStatsMap.put(uuid, stats);
        }
        
        return stats;
    }
    
    /**
     * 增加玩家的树木方块破坏统计
     * @param player 玩家
     * @param material 方块材料
     * @param count 数量
     */
    public void addTreeBlocksBroken(Player player, Material material, int count) {
        PlayerStats stats = getPlayerStats(player);
        stats.treeBlocksBroken += count;
        
        int currentCount = stats.treeBlocksByType.getOrDefault(material, 0);
        stats.treeBlocksByType.put(material, currentCount + count);
    }
    
    /**
     * 增加玩家的矿石方块破坏统计
     * @param player 玩家
     * @param material 方块材料
     * @param count 数量
     */
    public void addOreBlocksBroken(Player player, Material material, int count) {
        PlayerStats stats = getPlayerStats(player);
        stats.oreBlocksBroken += count;
        
        int currentCount = stats.oreBlocksByType.getOrDefault(material, 0);
        stats.oreBlocksByType.put(material, currentCount + count);
    }
    
    /**
     * 玩家统计数据类
     */
    public static class PlayerStats {
        private final UUID playerUuid;
        private int treeBlocksBroken;
        private int oreBlocksBroken;
        private final Map<Material, Integer> treeBlocksByType = new HashMap<>();
        private final Map<Material, Integer> oreBlocksByType = new HashMap<>();
        
        public PlayerStats(UUID playerUuid) {
            this.playerUuid = playerUuid;
            this.treeBlocksBroken = 0;
            this.oreBlocksBroken = 0;
        }
        
        public UUID getPlayerUuid() {
            return playerUuid;
        }
        
        public int getTreeBlocksBroken() {
            return treeBlocksBroken;
        }
        
        public int getOreBlocksBroken() {
            return oreBlocksBroken;
        }
        
        public Map<Material, Integer> getTreeBlocksByType() {
            return treeBlocksByType;
        }
        
        public Map<Material, Integer> getOreBlocksByType() {
            return oreBlocksByType;
        }
    }
}