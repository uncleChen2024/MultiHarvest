package com.minecraft.multiharvest.util;

import com.minecraft.multiharvest.MultiHarvest;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 通知管理器，用于显示各种类型的通知
 */
public class NotificationManager {
    
    private final MultiHarvest plugin;
    private final Map<UUID, BossBar> treeBossBars = new HashMap<>();
    private final Map<UUID, BossBar> mineBossBars = new HashMap<>();
    private final Map<UUID, BukkitTask> bossBarTasks = new HashMap<>();
    
    public enum NotificationType {
        CHAT,
        ACTION_BAR,
        BOSS_BAR
    }
    
    public NotificationManager(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 显示树砍伐次数通知
     * @param player 玩家
     * @param usedCount 已使用次数
     * @param limit 限制次数
     */
    public void showTreeChopNotification(Player player, int usedCount, int limit) {
        String notificationType = plugin.getConfigManager().getTreeChopNotificationType();
        int remaining = limit - usedCount;
        
        String message = plugin.getLanguageManager().getMessage("notification.tree_chop.remaining", player, remaining, limit);
        
        try {
            NotificationType type = NotificationType.valueOf(notificationType);
            showNotification(player, message, type, "tree", 
                    plugin.getConfigManager().getTreeChopBossBarColor(), 
                    plugin.getConfigManager().getTreeChopBossBarTime());
        } catch (IllegalArgumentException e) {
            // 默认使用聊天框
            player.sendMessage(message);
        }
    }
    
    /**
     * 显示矿石挖掘次数通知
     * @param player 玩家
     * @param usedCount 已使用次数
     * @param limit 限制次数
     */
    public void showChainMineNotification(Player player, int usedCount, int limit) {
        String notificationType = plugin.getConfigManager().getChainMineNotificationType();
        int remaining = limit - usedCount;
        
        String message = plugin.getLanguageManager().getMessage("notification.chain_mine.remaining", player, remaining, limit);
        
        try {
            NotificationType type = NotificationType.valueOf(notificationType);
            showNotification(player, message, type, "mine", 
                    plugin.getConfigManager().getChainMineBossBarColor(), 
                    plugin.getConfigManager().getChainMineBossBarTime());
        } catch (IllegalArgumentException e) {
            // 默认使用聊天框
            player.sendMessage(message);
        }
    }
    
    /**
     * 显示通知
     * @param player 玩家
     * @param message 消息
     * @param type 通知类型
     * @param featureType 功能类型（tree或mine）
     * @param bossBarColor Boss栏颜色
     * @param bossBarTime Boss栏显示时间（秒）
     */
    private void showNotification(Player player, String message, NotificationType type, String featureType, 
                                 String bossBarColor, int bossBarTime) {
        switch (type) {
            case CHAT:
                player.sendMessage(message);
                break;
                
            case ACTION_BAR:
                // 使用Spigot API发送动作栏消息
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(message));
                break;
                
            case BOSS_BAR:
                showBossBar(player, message, featureType, bossBarColor, bossBarTime);
                break;
        }
    }
    
    /**
     * 显示Boss栏通知
     * @param player 玩家
     * @param message 消息
     * @param featureType 功能类型（tree或mine）
     * @param colorName Boss栏颜色名称
     * @param time 显示时间（秒）
     */
    private void showBossBar(Player player, String message, String featureType, String colorName, int time) {
        UUID playerUuid = player.getUniqueId();
        Map<UUID, BossBar> bossBars = featureType.equals("tree") ? treeBossBars : mineBossBars;
        
        // 移除旧的Boss栏
        if (bossBars.containsKey(playerUuid)) {
            BossBar oldBar = bossBars.get(playerUuid);
            oldBar.removePlayer(player);
            bossBars.remove(playerUuid);
        }
        
        // 取消旧的任务
        if (bossBarTasks.containsKey(playerUuid)) {
            bossBarTasks.get(playerUuid).cancel();
            bossBarTasks.remove(playerUuid);
        }
        
        // 创建新的Boss栏
        BarColor color;
        try {
            color = BarColor.valueOf(colorName);
        } catch (IllegalArgumentException e) {
            color = featureType.equals("tree") ? BarColor.GREEN : BarColor.BLUE;
        }
        
        BossBar bossBar = Bukkit.createBossBar(message, color, BarStyle.SOLID);
        bossBar.addPlayer(player);
        bossBars.put(playerUuid, bossBar);
        
        // 设置定时任务，在指定时间后移除Boss栏
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            bossBar.removePlayer(player);
            bossBars.remove(playerUuid);
            bossBarTasks.remove(playerUuid);
        }, time * 20L); // 转换为tick
        
        bossBarTasks.put(playerUuid, task);
    }
    
    /**
     * 清理玩家的所有通知
     * @param player 玩家
     */
    public void clearNotifications(Player player) {
        UUID playerUuid = player.getUniqueId();
        
        // 清理树砍伐Boss栏
        if (treeBossBars.containsKey(playerUuid)) {
            treeBossBars.get(playerUuid).removePlayer(player);
            treeBossBars.remove(playerUuid);
        }
        
        // 清理矿石挖掘Boss栏
        if (mineBossBars.containsKey(playerUuid)) {
            mineBossBars.get(playerUuid).removePlayer(player);
            mineBossBars.remove(playerUuid);
        }
        
        // 取消定时任务
        if (bossBarTasks.containsKey(playerUuid)) {
            bossBarTasks.get(playerUuid).cancel();
            bossBarTasks.remove(playerUuid);
        }
    }
}