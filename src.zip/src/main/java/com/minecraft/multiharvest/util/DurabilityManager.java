package com.minecraft.multiharvest.util;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Random;

public class DurabilityManager {
    
    private final MultiHarvest plugin;
    private final Random random = new Random();
    
    public DurabilityManager(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 处理工具耐久度消耗
     * @param player 玩家
     * @param tool 工具
     * @param blockCount 破坏的方块数量
     * @return 工具是否已损坏
     */
    public boolean handleDurability(Player player, ItemStack tool, int blockCount) {
        if (tool == null || tool.getType() == Material.AIR) {
            return false;
        }
        
        // 检查工具是否有耐久度
        if (tool.getType().getMaxDurability() <= 0) {
            return false;
        }
        
        // 获取耐久度消耗配置
        boolean reducedDurability = plugin.getConfig().getBoolean("durability.reduced_consumption", true);
        double durabilityFactor = plugin.getConfig().getDouble("durability.factor", 0.2);
        
        // 计算实际消耗的耐久度
        int durabilityLoss = reducedDurability ? 
                calculateReducedDurabilityLoss(blockCount, durabilityFactor) : 
                blockCount;
        
        // 应用耐久度附魔效果
        durabilityLoss = applyUnbreakingEnchantment(tool, durabilityLoss);
        
        // 应用耐久度消耗
        if (durabilityLoss > 0) {
            ItemMeta meta = tool.getItemMeta();
            if (meta instanceof Damageable) {
                Damageable damageable = (Damageable) meta;
                int currentDamage = damageable.getDamage();
                int maxDurability = tool.getType().getMaxDurability();
                
                // 计算新的损坏值
                int newDamage = currentDamage + durabilityLoss;
                
                // 检查工具是否会损坏
                if (newDamage >= maxDurability) {
                    // 工具损坏
                    if (hasInfinityDurability(player)) {
                        // 无限耐久权限，将损坏值设为最大值-1
                        damageable.setDamage(maxDurability - 1);
                    } else {
                        // 工具损坏，数量减少为0
                        tool.setAmount(0);
                        return true;
                    }
                } else {
                    // 更新损坏值
                    damageable.setDamage(newDamage);
                }
                
                tool.setItemMeta(meta);
            }
        }
        
        return false;
    }
    
    /**
     * 计算减少后的耐久度消耗
     * @param blockCount 破坏的方块数量
     * @param factor 消耗因子
     * @return 实际消耗的耐久度
     */
    private int calculateReducedDurabilityLoss(int blockCount, double factor) {
        // 至少消耗1点耐久度
        return Math.max(1, (int) Math.ceil(blockCount * factor));
    }
    
    /**
     * 应用耐久附魔效果
     * @param tool 工具
     * @param durabilityLoss 原始耐久度消耗
     * @return 实际耐久度消耗
     */
    private int applyUnbreakingEnchantment(ItemStack tool, int durabilityLoss) {
        int unbreakingLevel = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
        
        if (unbreakingLevel <= 0) {
            return durabilityLoss;
        }
        
        int finalLoss = 0;
        
        // 对每点耐久度损失单独计算
        for (int i = 0; i < durabilityLoss; i++) {
            // 耐久附魔有 100/(level+1)% 的几率消耗耐久度
            if (random.nextInt(100) < (100 / (unbreakingLevel + 1))) {
                finalLoss++;
            }
        }
        
        return finalLoss;
    }
    
    /**
     * 检查玩家是否有无限耐久权限
     * @param player 玩家
     * @return 是否有无限耐久权限
     */
    private boolean hasInfinityDurability(Player player) {
        return player.hasPermission("multiharvest.infinitydurability") || player.isOp();
    }
}