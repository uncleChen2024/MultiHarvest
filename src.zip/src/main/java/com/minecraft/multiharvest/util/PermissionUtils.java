package com.minecraft.multiharvest.util;

import org.bukkit.entity.Player;

public class PermissionUtils {
    
    // 基础权限
    public static final String PERMISSION_USE = "multiharvest.use";
    public static final String PERMISSION_TREE = "multiharvest.tree";
    public static final String PERMISSION_MINE = "multiharvest.mine";
    public static final String PERMISSION_ADMIN = "multiharvest.admin";
    public static final String PERMISSION_VIP = "multiharvest.vip";
    
    // 无限制权限
    public static final String PERMISSION_UNLIMITED_TREE = "multiharvest.unlimited.tree";
    public static final String PERMISSION_UNLIMITED_MINE = "multiharvest.unlimited.mine";
    public static final String PERMISSION_UNLIMITED_ALL = "multiharvest.unlimited.all";
    
    /**
     * 检查玩家是否有使用插件的权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean canUse(Player player) {
        return player.hasPermission(PERMISSION_USE) || player.isOp();
    }
    
    /**
     * 检查玩家是否有使用自动砍树功能的权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean canUseTreeChop(Player player) {
        return player.hasPermission(PERMISSION_TREE) || player.hasPermission(PERMISSION_USE) || player.isOp();
    }
    
    /**
     * 检查玩家是否有使用连锁挖矿功能的权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean canUseChainMine(Player player) {
        return player.hasPermission(PERMISSION_MINE) || player.hasPermission(PERMISSION_USE) || player.isOp();
    }
    
    /**
     * 检查玩家是否有管理员权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean isAdmin(Player player) {
        return player.hasPermission(PERMISSION_ADMIN) || player.isOp();
    }
    
    /**
     * 检查玩家是否有VIP权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean isVip(Player player) {
        return player.hasPermission(PERMISSION_VIP) || player.isOp();
    }
    
    /**
     * 检查玩家是否有无限自动砍树权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean hasUnlimitedTreeChop(Player player) {
        return player.hasPermission(PERMISSION_UNLIMITED_TREE) || 
               player.hasPermission(PERMISSION_UNLIMITED_ALL) || 
               player.isOp();
    }
    
    /**
     * 检查玩家是否有无限连锁挖矿权限
     * @param player 玩家
     * @return 是否有权限
     */
    public static boolean hasUnlimitedChainMine(Player player) {
        return player.hasPermission(PERMISSION_UNLIMITED_MINE) || 
               player.hasPermission(PERMISSION_UNLIMITED_ALL) || 
               player.isOp();
    }
}