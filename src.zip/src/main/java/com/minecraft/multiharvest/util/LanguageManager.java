package com.minecraft.multiharvest.util;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LanguageManager {
    
    private final MultiHarvest plugin;
    private final Map<String, FileConfiguration> languages = new HashMap<>();
    private final Map<UUID, String> playerLanguages = new HashMap<>();
    private String defaultLanguage;
    
    private final File playerLangFile;
    
    public LanguageManager(MultiHarvest plugin) {
        this.plugin = plugin;
        this.defaultLanguage = plugin.getConfig().getString("language.default", "zh_CN");
        this.playerLangFile = new File(plugin.getDataFolder(), "player_languages.yml");
        loadLanguages();
        loadPlayerLanguageSettings();
    }
    
    /**
     * 加载所有语言文件
     */
    public void loadLanguages() {
        languages.clear();
        
        // 确保语言文件目录存在
        File langDir = new File(plugin.getDataFolder(), "lang");
        if (!langDir.exists()) {
            langDir.mkdirs();
        }
        
        // 保存默认语言文件
        saveDefaultLanguageFile("zh_CN");
        saveDefaultLanguageFile("en_US");
        
        // 加载所有语言文件
        File[] langFiles = langDir.listFiles((dir, name) -> name.endsWith(".yml"));
        if (langFiles != null) {
            for (File file : langFiles) {
                String langCode = file.getName().replace(".yml", "");
                FileConfiguration langConfig = YamlConfiguration.loadConfiguration(file);
                languages.put(langCode, langConfig);
            }
        }
        
        plugin.getLogger().info("已加载 " + languages.size() + " 个语言文件");
    }
    
    /**
     * 保存默认语言文件
     * @param langCode 语言代码
     */
    private void saveDefaultLanguageFile(String langCode) {
        File langFile = new File(plugin.getDataFolder(), "lang/" + langCode + ".yml");
        if (!langFile.exists()) {
            InputStream in = plugin.getResource("lang/" + langCode + ".yml");
            if (in != null) {
                try {
                    FileConfiguration langConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
                    langConfig.save(langFile);
                    plugin.getLogger().info("已保存默认语言文件: " + langCode);
                } catch (Exception e) {
                    plugin.getLogger().severe("无法保存默认语言文件: " + langCode);
                    e.printStackTrace();
                }
            }
        }
    }
    
    /**
     * 获取玩家的语言设置
     * @param player 玩家
     * @return 语言代码
     */
    public String getPlayerLanguage(Player player) {
        UUID uuid = player.getUniqueId();
        return playerLanguages.getOrDefault(uuid, defaultLanguage);
    }
    
    /**
     * 加载玩家语言设置
     */
    private void loadPlayerLanguageSettings() {
        playerLanguages.clear();
        
        if (!playerLangFile.exists()) {
            return;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerLangFile);
        for (String uuidStr : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                String langCode = config.getString(uuidStr);
                if (langCode != null && languages.containsKey(langCode)) {
                    playerLanguages.put(uuid, langCode);
                }
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("无效的UUID: " + uuidStr);
            }
        }
        
        plugin.getLogger().info("已加载 " + playerLanguages.size() + " 个玩家的语言设置");
    }
    
    /**
     * 保存玩家语言设置
     */
    public void savePlayerLanguageSettings() {
        FileConfiguration config = new YamlConfiguration();
        
        for (Map.Entry<UUID, String> entry : playerLanguages.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }
        
        try {
            config.save(playerLangFile);
        } catch (Exception e) {
            plugin.getLogger().severe("无法保存玩家语言设置");
            e.printStackTrace();
        }
    }
    
    /**
     * 设置玩家的语言
     * @param player 玩家
     * @param langCode 语言代码
     */
    public void setPlayerLanguage(Player player, String langCode) {
        if (languages.containsKey(langCode)) {
            playerLanguages.put(player.getUniqueId(), langCode);
            savePlayerLanguageSettings();
            player.sendMessage(ChatColor.GREEN + "语言已设置为: " + langCode);
        } else {
            player.sendMessage(ChatColor.RED + "不支持的语言: " + langCode);
        }
    }
    
    /**
     * 获取翻译文本
     * @param key 文本键
     * @param player 玩家
     * @param args 替换参数
     * @return 翻译后的文本
     */
    public String getMessage(String key, Player player, Object... args) {
        String langCode = getPlayerLanguage(player);
        return getMessageFromLang(key, langCode, args);
    }
    
    /**
     * 从指定语言获取翻译文本
     * @param key 文本键
     * @param langCode 语言代码
     * @param args 替换参数
     * @return 翻译后的文本
     */
    public String getMessageFromLang(String key, String langCode, Object... args) {
        FileConfiguration langConfig = languages.get(langCode);
        
        if (langConfig == null) {
            langConfig = languages.get(defaultLanguage);
        }
        
        if (langConfig == null) {
            return "Missing language: " + key;
        }
        
        String message = langConfig.getString(key);
        
        if (message == null) {
            // 尝试从默认语言获取
            FileConfiguration defaultConfig = languages.get(defaultLanguage);
            if (defaultConfig != null) {
                message = defaultConfig.getString(key);
            }
            
            if (message == null) {
                return "Missing translation: " + key;
            }
        }
        
        // 替换参数
        for (int i = 0; i < args.length; i++) {
            message = message.replace("{" + i + "}", String.valueOf(args[i]));
        }
        
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    /**
     * 获取可用的语言列表
     * @return 语言列表
     */
    public Map<String, String> getAvailableLanguages() {
        Map<String, String> result = new HashMap<>();
        
        for (String langCode : languages.keySet()) {
            FileConfiguration langConfig = languages.get(langCode);
            String langName = langConfig.getString("language.name", langCode);
            result.put(langCode, langName);
        }
        
        return result;
    }
}