package com.minecraft.multiharvest.util;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownUtils {
    
    private final MultiHarvest plugin;
    private final Map<UUID, Long> treeCooldowns = new HashMap<>();
    private final Map<UUID, Long> mineCooldowns = new HashMap<>();
    
    public CooldownUtils(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 检查玩家是否可以使用自动砍树功能
     * @param player 玩家
     * @return 是否可以使用
     */
    public boolean canUseTreeChop(Player player) {
        UUID uuid = player.getUniqueId();
        
        if (!treeCooldowns.containsKey(uuid)) {
            return true;
        }
        
        long cooldownTime = PermissionUtils.isVip(player) ? 
                plugin.getConfigManager().getVipCooldown() : 
                plugin.getConfigManager().getNormalCooldown();
        
        long lastUsed = treeCooldowns.get(uuid);
        long currentTime = System.currentTimeMillis() / 1000;
        
        return (currentTime - lastUsed) >= cooldownTime;
    }
    
    /**
     * 检查玩家是否可以使用连锁挖矿功能
     * @param player 玩家
     * @return 是否可以使用
     */
    public boolean canUseChainMine(Player player) {
        UUID uuid = player.getUniqueId();
        
        if (!mineCooldowns.containsKey(uuid)) {
            return true;
        }
        
        long cooldownTime = PermissionUtils.isVip(player) ? 
                plugin.getConfigManager().getVipCooldown() : 
                plugin.getConfigManager().getNormalCooldown();
        
        long lastUsed = mineCooldowns.get(uuid);
        long currentTime = System.currentTimeMillis() / 1000;
        
        return (currentTime - lastUsed) >= cooldownTime;
    }
    
    /**
     * 设置玩家自动砍树功能的冷却时间
     * @param player 玩家
     */
    public void setTreeCooldown(Player player) {
        treeCooldowns.put(player.getUniqueId(), System.currentTimeMillis() / 1000);
    }
    
    /**
     * 设置玩家连锁挖矿功能的冷却时间
     * @param player 玩家
     */
    public void setMineCooldown(Player player) {
        mineCooldowns.put(player.getUniqueId(), System.currentTimeMillis() / 1000);
    }
    
    /**
     * 获取玩家自动砍树功能的剩余冷却时间
     * @param player 玩家
     * @return 剩余冷却时间（秒）
     */
    public int getRemainingTreeCooldown(Player player) {
        UUID uuid = player.getUniqueId();
        
        if (!treeCooldowns.containsKey(uuid)) {
            return 0;
        }
        
        long cooldownTime = PermissionUtils.isVip(player) ? 
                plugin.getConfigManager().getVipCooldown() : 
                plugin.getConfigManager().getNormalCooldown();
        
        long lastUsed = treeCooldowns.get(uuid);
        long currentTime = System.currentTimeMillis() / 1000;
        long elapsed = currentTime - lastUsed;
        
        return elapsed >= cooldownTime ? 0 : (int) (cooldownTime - elapsed);
    }
    
    /**
     * 获取玩家连锁挖矿功能的剩余冷却时间
     * @param player 玩家
     * @return 剩余冷却时间（秒）
     */
    public int getRemainingMineCooldown(Player player) {
        UUID uuid = player.getUniqueId();
        
        if (!mineCooldowns.containsKey(uuid)) {
            return 0;
        }
        
        long cooldownTime = PermissionUtils.isVip(player) ? 
                plugin.getConfigManager().getVipCooldown() : 
                plugin.getConfigManager().getNormalCooldown();
        
        long lastUsed = mineCooldowns.get(uuid);
        long currentTime = System.currentTimeMillis() / 1000;
        long elapsed = currentTime - lastUsed;
        
        return elapsed >= cooldownTime ? 0 : (int) (cooldownTime - elapsed);
    }
}