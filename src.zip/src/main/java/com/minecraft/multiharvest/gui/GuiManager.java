package com.minecraft.multiharvest.gui;

import com.minecraft.multiharvest.MultiHarvest;
import com.minecraft.multiharvest.config.PlayerData;
import com.minecraft.multiharvest.util.PermissionUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class GuiManager {
    
    private final MultiHarvest plugin;
    private final TreeConfigGui treeConfigGui;
    private final MineConfigGui mineConfigGui;
    private final WorldConfigGui worldConfigGui;
    
    public static final String MAIN_GUI_TITLE = ChatColor.DARK_GREEN + "多功能自动采集";
    public static final String TREE_CONFIG_GUI_TITLE = ChatColor.DARK_GREEN + "自动砍树配置";
    public static final String MINE_CONFIG_GUI_TITLE = ChatColor.DARK_GREEN + "连锁挖矿配置";
    public static final String WORLD_CONFIG_GUI_TITLE = ChatColor.DARK_GREEN + "世界控制配置";
    
    public GuiManager(MultiHarvest plugin) {
        this.plugin = plugin;
        this.treeConfigGui = new TreeConfigGui(plugin);
        this.mineConfigGui = new MineConfigGui(plugin);
        this.worldConfigGui = new WorldConfigGui(plugin);
    }
    
    /**
     * 打开主菜单GUI
     * @param player 玩家
     */
    public void openMainGui(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, MAIN_GUI_TITLE);
        
        // 获取玩家数据
        PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
        
        // 自动砍树开关
        ItemStack treeToggle = createItem(
                playerData.isTreeChopEnabled() ? Material.OAK_LOG : Material.BARRIER,
                ChatColor.GOLD + "自动砍树",
                ChatColor.GRAY + "状态: " + (playerData.isTreeChopEnabled() ? ChatColor.GREEN + "已启用" : ChatColor.RED + "已禁用"),
                ChatColor.YELLOW + "点击切换状态"
        );
        gui.setItem(11, treeToggle);
        
        // 连锁挖矿开关
        ItemStack mineToggle = createItem(
                playerData.isChainMineEnabled() ? Material.DIAMOND_ORE : Material.BARRIER,
                ChatColor.AQUA + "连锁挖矿",
                ChatColor.GRAY + "状态: " + (playerData.isChainMineEnabled() ? ChatColor.GREEN + "已启用" : ChatColor.RED + "已禁用"),
                ChatColor.YELLOW + "点击切换状态"
        );
        gui.setItem(15, mineToggle);
        
        // 如果是管理员，显示配置选项
        if (PermissionUtils.isAdmin(player)) {
            ItemStack treeConfig = createItem(
                    Material.CRAFTING_TABLE,
                    ChatColor.GREEN + "自动砍树配置",
                    ChatColor.GRAY + "配置可自动砍伐的方块类型",
                    ChatColor.YELLOW + "点击打开配置界面"
            );
            gui.setItem(12, treeConfig);
            
            ItemStack mineConfig = createItem(
                    Material.CRAFTING_TABLE,
                    ChatColor.GREEN + "连锁挖矿配置",
                    ChatColor.GRAY + "配置可连锁挖掘的方块类型",
                    ChatColor.YELLOW + "点击打开配置界面"
            );
            gui.setItem(14, mineConfig);
            
            ItemStack worldConfig = createItem(
                    Material.GLOBE_BANNER_PATTERN,
                    ChatColor.GREEN + "世界控制配置",
                    ChatColor.GRAY + "配置哪些世界可以使用功能",
                    ChatColor.YELLOW + "点击打开配置界面"
            );
            gui.setItem(13, worldConfig);
        }
        
        // 信息
        ItemStack info = createItem(
                Material.BOOK,
                ChatColor.GOLD + "插件信息",
                ChatColor.GRAY + "MultiHarvest v1.0",
                ChatColor.GRAY + "作者: Golden_Dragon",
                "",
                ChatColor.YELLOW + "提示: 潜行时可临时禁用功能"
        );
        gui.setItem(22, info);
        
        player.openInventory(gui);
    }
    
    
    /**
     * 打开自动砍树配置GUI
     * @param player 玩家
     */
    public void openTreeConfigGui(Player player) {
        if (!PermissionUtils.isAdmin(player)) {
            player.sendMessage(ChatColor.RED + "你没有权限访问此配置！");
            return;
        }
        
        treeConfigGui.openGui(player);
    }
    
    /**
     * 打开连锁挖矿配置GUI
     * @param player 玩家
     */
    public void openMineConfigGui(Player player) {
        if (!PermissionUtils.isAdmin(player)) {
            player.sendMessage(ChatColor.RED + "你没有权限访问此配置！");
            return;
        }
        
        mineConfigGui.openGui(player);
    }
    
    /**
     * 打开世界控制配置GUI
     * @param player 玩家
     */
    public void openWorldConfigGui(Player player) {
        if (!PermissionUtils.isAdmin(player)) {
            player.sendMessage(ChatColor.RED + "你没有权限访问此配置！");
            return;
        }
        
        worldConfigGui.openGui(player);
    }
    
    /**
     * 处理世界配置GUI的点击事件
     * @param player 玩家
     * @param slot 点击的槽位
     * @param inventory 库存
     */
    public void handleWorldConfigClick(Player player, int slot, Inventory inventory) {
        worldConfigGui.handleClick(player, slot, inventory);
    }
    
    /**
     * 保存自动砍树配置
     * @param inventory 库存
     */
    public void saveTreeConfig(Inventory inventory) {
        treeConfigGui.saveConfig(inventory);
    }
    
    /**
     * 处理自动砍树配置界面的点击事件
     * @param player 玩家
     * @param slot 槽位
     * @param inventory 库存
     */
    public void handleTreeConfigClick(Player player, int slot, Inventory inventory) {
        treeConfigGui.handleClick(player, slot, inventory);
    }
    
    /**
     * 保存连锁挖矿配置
     * @param inventory 库存
     */
    public void saveMineConfig(Inventory inventory) {
        mineConfigGui.saveConfig(inventory);
    }
    
    /**
     * 处理连锁挖矿配置界面的点击事件
     * @param player 玩家
     * @param slot 槽位
     * @param inventory 库存
     */
    public void handleMineConfigClick(Player player, int slot, Inventory inventory) {
        mineConfigGui.handleClick(player, slot, inventory);
    }
    
    /**
     * 创建物品
     * @param material 材料
     * @param name 名称
     * @param lore 描述
     * @return 物品
     */
    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(name);
            
            if (lore.length > 0) {
                List<String> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(line);
                }
                meta.setLore(loreList);
            }
            
            item.setItemMeta(meta);
        }
        
        return item;
    }
}