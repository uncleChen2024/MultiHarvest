package com.minecraft.multiharvest.gui;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class WorldConfigGui {
    
    private final MultiHarvest plugin;
    public static final String WORLD_CONFIG_GUI_TITLE = ChatColor.DARK_GREEN + "世界控制配置";
    
    public WorldConfigGui(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 打开世界配置GUI
     * @param player 玩家
     */
    public void openGui(Player player) {
        // 获取所有世界
        List<World> worlds = Bukkit.getWorlds();
        
        // 计算需要的GUI大小（向上取整到9的倍数）
        int size = (int) Math.ceil(worlds.size() / 9.0) * 9;
        size = Math.max(27, size); // 至少27格
        
        Inventory gui = Bukkit.createInventory(null, size, WORLD_CONFIG_GUI_TITLE);
        
        // 获取已启用的世界列表
        Set<String> enabledWorlds = plugin.getConfigManager().getEnabledWorlds();
        boolean isWhitelistMode = plugin.getConfigManager().isWorldWhitelistMode();
        
        // 添加世界项
        int slot = 0;
        for (World world : worlds) {
            String worldName = world.getName();
            boolean isEnabled = plugin.getConfigManager().isWorldEnabled(worldName);
            
            Material material;
            switch (worldName.toLowerCase()) {
                case "world":
                    material = Material.GRASS_BLOCK;
                    break;
                case "world_nether":
                    material = Material.NETHERRACK;
                    break;
                case "world_the_end":
                    material = Material.END_STONE;
                    break;
                default:
                    material = Material.DIRT;
                    break;
            }
            
            ItemStack item = createItem(
                    material,
                    ChatColor.GOLD + worldName,
                    ChatColor.GRAY + "状态: " + (isEnabled ? ChatColor.GREEN + "已启用" : ChatColor.RED + "已禁用"),
                    ChatColor.YELLOW + "点击切换状态"
            );
            
            gui.setItem(slot++, item);
        }
        
        // 添加模式切换按钮
        ItemStack modeToggle = createItem(
                Material.COMPARATOR,
                ChatColor.AQUA + "模式: " + (isWhitelistMode ? ChatColor.GREEN + "白名单" : ChatColor.RED + "黑名单"),
                ChatColor.GRAY + "白名单: 只有列表中的世界可以使用功能",
                ChatColor.GRAY + "黑名单: 列表中的世界不能使用功能",
                ChatColor.YELLOW + "点击切换模式"
        );
        gui.setItem(size - 5, modeToggle);
        
        // 添加返回按钮
        ItemStack backButton = createItem(
                Material.ARROW,
                ChatColor.YELLOW + "返回主菜单",
                ChatColor.GRAY + "点击返回"
        );
        gui.setItem(size - 1, backButton);
        
        player.openInventory(gui);
    }
    
    /**
     * 处理世界配置GUI的点击事件
     * @param player 玩家
     * @param slot 点击的槽位
     */
    public void handleClick(Player player, int slot, Inventory inventory) {
        List<World> worlds = Bukkit.getWorlds();
        int size = inventory.getSize();
        
        // 如果点击的是世界项
        if (slot < worlds.size()) {
            World world = worlds.get(slot);
            String worldName = world.getName();
            
            // 切换世界状态
            plugin.getConfigManager().toggleWorldEnabled(worldName);
            
            // 更新物品显示
            boolean isEnabled = plugin.getConfigManager().isWorldEnabled(worldName);
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getItemMeta() != null) {
                ItemMeta meta = item.getItemMeta();
                List<String> lore = meta.getLore();
                if (lore != null && !lore.isEmpty()) {
                    lore.set(0, ChatColor.GRAY + "状态: " + (isEnabled ? ChatColor.GREEN + "已启用" : ChatColor.RED + "已禁用"));
                    meta.setLore(lore);
                    item.setItemMeta(meta);
                }
            }
            
            // 发送消息
            String status = isEnabled ? plugin.getLanguageManager().getMessage("feature.world.enabled", player) : 
                                       plugin.getLanguageManager().getMessage("feature.world.disabled", player);
            player.sendMessage(plugin.getLanguageManager().getMessage("feature.world.toggle", player, worldName, status));
        }
        // 如果点击的是模式切换按钮
        else if (slot == size - 5) {
            // 切换模式
            boolean newMode = !plugin.getConfigManager().isWorldWhitelistMode();
            plugin.getConfig().set("worlds.whitelist-mode", newMode);
            plugin.saveConfig();
            plugin.getConfigManager().loadConfig(); // 重新加载配置
            
            // 更新物品显示
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getItemMeta() != null) {
                ItemMeta meta = item.getItemMeta();
                meta.setDisplayName(ChatColor.AQUA + "模式: " + (newMode ? ChatColor.GREEN + "白名单" : ChatColor.RED + "黑名单"));
                item.setItemMeta(meta);
            }
            
            // 刷新GUI以更新所有世界的状态显示
            openGui(player);
        }
        // 如果点击的是返回按钮
        else if (slot == size - 1) {
            plugin.getGuiManager().openMainGui(player);
        }
    }
    
    /**
     * 创建物品
     * @param material 材料
     * @param name 名称
     * @param lore 描述
     * @return 物品
     */
    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(name);
            
            if (lore.length > 0) {
                List<String> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(line);
                }
                meta.setLore(loreList);
            }
            
            item.setItemMeta(meta);
        }
        
        return item;
    }
}