package com.minecraft.multiharvest.gui;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 连锁挖矿配置界面
 */
public class MineConfigGui {
    
    private final MultiHarvest plugin;
    
    public MineConfigGui(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 打开连锁挖矿配置界面
     * @param player 玩家
     */
    public void openGui(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, GuiManager.MINE_CONFIG_GUI_TITLE);
        
        // 添加说明
        ItemStack info = createItem(
                Material.PAPER,
                ChatColor.GOLD + "连锁挖矿配置",
                ChatColor.GRAY + "点击方块来切换是否加入连锁挖掘的方块类型",
                ChatColor.GRAY + "蓝色边框表示已启用，红色边框表示未启用"
        );
        gui.setItem(4, info);
        
        // 添加返回按钮
        ItemStack back = createItem(
                Material.ARROW,
                ChatColor.YELLOW + "返回主菜单"
        );
        gui.setItem(0, back);
        
        // 添加保存按钮
        ItemStack save = createItem(
                Material.EMERALD,
                ChatColor.GREEN + "保存配置"
        );
        gui.setItem(8, save);
        
        // 添加翻页按钮
        ItemStack prevPage = createItem(
                Material.ARROW,
                ChatColor.YELLOW + "上一页"
        );
        gui.setItem(45, prevPage);
        
        ItemStack nextPage = createItem(
                Material.ARROW,
                ChatColor.YELLOW + "下一页"
        );
        gui.setItem(53, nextPage);
        
        // 获取当前配置的方块
        Set<Material> oreBlocks = plugin.getConfigManager().getOreBlocks();
        
        // 添加所有可能的矿石方块
        List<Material> allOreBlocks = getAllOreBlocks();
        int slot = 18;
        
        for (Material material : allOreBlocks) {
            if (slot < 45) { // 留出底部一行给翻页按钮
                boolean isEnabled = oreBlocks.contains(material);
                
                ItemStack item = new ItemStack(material);
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName((isEnabled ? ChatColor.AQUA : ChatColor.RED) + formatMaterialName(material.name()));
                    List<String> lore = new ArrayList<>();
                    lore.add(isEnabled ? 
                            ChatColor.AQUA + "已启用 - 点击禁用" : 
                            ChatColor.RED + "已禁用 - 点击启用");
                    meta.setLore(lore);
                    item.setItemMeta(meta);
                }
                gui.setItem(slot++, item);
            }
        }
        
        player.openInventory(gui);
    }
    
    /**
     * 保存配置
     * @param inventory 库存
     */
    public void saveConfig(Inventory inventory) {
        // 配置已经在点击时实时更新，这里只需要保存配置文件
        plugin.getConfigManager().saveConfig();
    }
    
    /**
     * 处理点击事件
     * @param player 玩家
     * @param slot 槽位
     * @param inventory 库存
     */
    public void handleClick(Player player, int slot, Inventory inventory) {
        if (slot >= 18 && slot < 45) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                Material material = item.getType();
                Set<Material> oreBlocks = plugin.getConfigManager().getOreBlocks();
                
                // 切换状态
                boolean isEnabled = oreBlocks.contains(material);
                if (isEnabled) {
                    oreBlocks.remove(material);
                } else {
                    oreBlocks.add(material);
                }
                
                // 更新物品显示
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName((!isEnabled ? ChatColor.AQUA : ChatColor.RED) + formatMaterialName(material.name()));
                    List<String> lore = new ArrayList<>();
                    lore.add(!isEnabled ? 
                            ChatColor.AQUA + "已启用 - 点击禁用" : 
                            ChatColor.RED + "已禁用 - 点击启用");
                    meta.setLore(lore);
                    item.setItemMeta(meta);
                }
                
                // 播放音效
                player.playSound(player.getLocation(), 
                        !isEnabled ? org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING : org.bukkit.Sound.BLOCK_NOTE_BLOCK_BASS, 
                        0.5f, !isEnabled ? 1.2f : 0.8f);
            }
        } else if (slot == 45) {
            // 上一页
            // TODO: 实现翻页功能
        } else if (slot == 53) {
            // 下一页
            // TODO: 实现翻页功能
        }
    }
    
    /**
     * 获取所有可能的矿石方块
     * @return 矿石方块列表
     */
    private List<Material> getAllOreBlocks() {
        List<Material> oreBlocks = new ArrayList<>();
        
        // 添加所有矿石类型
        for (Material material : Material.values()) {
            String name = material.name();
            if (name.contains("_ORE") || name.contains("ANCIENT_DEBRIS")) {
                oreBlocks.add(material);
            }
        }
        
        return oreBlocks;
    }
    
    /**
     * 格式化材料名称
     * @param name 材料名称
     * @return 格式化后的名称
     */
    private String formatMaterialName(String name) {
        String[] parts = name.split("_");
        StringBuilder result = new StringBuilder();
        
        for (String part : parts) {
            if (part.length() > 0) {
                result.append(part.substring(0, 1).toUpperCase())
                      .append(part.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        
        return result.toString().trim();
    }
    
    /**
     * 创建物品
     * @param material 材料
     * @param name 名称
     * @param lore 描述
     * @return 物品
     */
    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(name);
            
            if (lore.length > 0) {
                List<String> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(line);
                }
                meta.setLore(loreList);
            }
            
            item.setItemMeta(meta);
        }
        
        return item;
    }
}