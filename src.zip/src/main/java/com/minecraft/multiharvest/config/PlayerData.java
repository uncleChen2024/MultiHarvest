package com.minecraft.multiharvest.config;

import java.util.UUID;

public class PlayerData {
    
    private final UUID playerUuid;
    private boolean treeChopEnabled;
    private boolean chainMineEnabled;
    
    // 使用次数统计
    private int treeChopUsedToday;
    private int chainMineUsedToday;
    private long lastResetDay; // 上次重置计数的日期（毫秒时间戳）
    
    public PlayerData(UUID playerUuid) {
        this.playerUuid = playerUuid;
        this.treeChopEnabled = true;
        this.chainMineEnabled = true;
        this.treeChopUsedToday = 0;
        this.chainMineUsedToday = 0;
        this.lastResetDay = System.currentTimeMillis();
    }
    
    public UUID getPlayerUuid() {
        return playerUuid;
    }
    
    public boolean isTreeChopEnabled() {
        return treeChopEnabled;
    }
    
    public void setTreeChopEnabled(boolean treeChopEnabled) {
        this.treeChopEnabled = treeChopEnabled;
    }
    
    public boolean isChainMineEnabled() {
        return chainMineEnabled;
    }
    
    public void setChainMineEnabled(boolean chainMineEnabled) {
        this.chainMineEnabled = chainMineEnabled;
    }
    
    public void toggleTreeChop() {
        this.treeChopEnabled = !this.treeChopEnabled;
    }
    
    public void toggleChainMine() {
        this.chainMineEnabled = !this.chainMineEnabled;
    }
    
    /**
     * 检查并重置每日使用次数
     */
    public void checkAndResetDailyUsage() {
        long currentTime = System.currentTimeMillis();
        long currentDay = currentTime / (24 * 60 * 60 * 1000);
        long lastDay = lastResetDay / (24 * 60 * 60 * 1000);
        
        if (currentDay > lastDay) {
            // 如果是新的一天，重置使用次数
            treeChopUsedToday = 0;
            chainMineUsedToday = 0;
            lastResetDay = currentTime;
        }
    }
    
    /**
     * 增加自动砍树使用次数
     * @return 增加后的使用次数
     */
    public int incrementTreeChopUsage() {
        checkAndResetDailyUsage();
        return ++treeChopUsedToday;
    }
    
    /**
     * 增加连锁挖矿使用次数
     * @return 增加后的使用次数
     */
    public int incrementChainMineUsage() {
        checkAndResetDailyUsage();
        return ++chainMineUsedToday;
    }
    
    /**
     * 获取今日已使用的自动砍树次数
     * @return 使用次数
     */
    public int getTreeChopUsedToday() {
        checkAndResetDailyUsage();
        return treeChopUsedToday;
    }
    
    /**
     * 获取今日已使用的连锁挖矿次数
     * @return 使用次数
     */
    public int getChainMineUsedToday() {
        checkAndResetDailyUsage();
        return chainMineUsedToday;
    }
    
    /**
     * 获取上次重置计数的时间
     * @return 时间戳（毫秒）
     */
    public long getLastResetDay() {
        return lastResetDay;
    }
    
    /**
     * 设置上次重置计数的时间
     * @param lastResetDay 时间戳（毫秒）
     */
    public void setLastResetDay(long lastResetDay) {
        this.lastResetDay = lastResetDay;
    }
}