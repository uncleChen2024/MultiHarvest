package com.minecraft.multiharvest.config;

import com.minecraft.multiharvest.MultiHarvest;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ConfigManager {
    
    private final MultiHarvest plugin;
    private FileConfiguration config;
    private File configFile;
    
    private final Map<UUID, PlayerData> playerDataMap = new HashMap<>();
    private final Set<Material> treeBlocks = new HashSet<>();
    private final Set<Material> leafBlocks = new HashSet<>();
    private final Set<Material> oreBlocks = new HashSet<>();
    private final Set<String> enabledWorlds = new HashSet<>();
    
    private int normalCooldown;
    private int vipCooldown;
    private int maxTreeBlocks;
    private int maxOreBlocks;
    
    // 使用次数限制
    private boolean treeChopLimitEnabled;
    private int defaultTreeChopLimit;
    private int vipTreeChopLimit;
    private String treeChopNotificationType;
    private boolean treeChopAlwaysShowNotification;
    private String treeChopBossBarColor;
    private int treeChopBossBarTime;
    
    private boolean chainMineLimitEnabled;
    private int defaultChainMineLimit;
    private int vipChainMineLimit;
    private String chainMineNotificationType;
    private boolean chainMineAlwaysShowNotification;
    private String chainMineBossBarColor;
    private int chainMineBossBarTime;
    
    // 世界设置
    private boolean worldWhitelistMode;
    
    // 功能设置
    private boolean requireAxeForTreeChop;
    private boolean clearLeaves;
    private boolean mustChopBottom;
    private boolean collectTreeDrops;
    private boolean requirePickaxeForChainMine;
    private boolean collectOreDrops;
    
    public ConfigManager(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    public void loadConfig() {
        // 确保配置文件存在
        if (!new File(plugin.getDataFolder(), "config.yml").exists()) {
            plugin.saveDefaultConfig();
        }
        
        // 加载配置
        plugin.reloadConfig();
        config = plugin.getConfig();
        
        // 加载冷却时间设置
        normalCooldown = config.getInt("cooldown.normal", 5);
        vipCooldown = config.getInt("cooldown.vip", 2);
        
        // 加载最大处理方块数
        maxTreeBlocks = config.getInt("limits.max-tree-blocks", 200);
        maxOreBlocks = config.getInt("limits.max-ore-blocks", 64);
        
        // 加载使用次数限制
        treeChopLimitEnabled = config.getBoolean("usage-limits.tree-chop.enabled", true);
        defaultTreeChopLimit = config.getInt("usage-limits.tree-chop.default", 50);
        vipTreeChopLimit = config.getInt("usage-limits.tree-chop.vip", 100);
        treeChopNotificationType = config.getString("usage-limits.tree-chop.notification.type", "ACTION_BAR");
        treeChopAlwaysShowNotification = config.getBoolean("usage-limits.tree-chop.notification.always-show", false);
        treeChopBossBarColor = config.getString("usage-limits.tree-chop.notification.boss-bar-color", "GREEN");
        treeChopBossBarTime = config.getInt("usage-limits.tree-chop.notification.boss-bar-time", 3);
        
        chainMineLimitEnabled = config.getBoolean("usage-limits.chain-mine.enabled", true);
        defaultChainMineLimit = config.getInt("usage-limits.chain-mine.default", 30);
        vipChainMineLimit = config.getInt("usage-limits.chain-mine.vip", 60);
        chainMineNotificationType = config.getString("usage-limits.chain-mine.notification.type", "ACTION_BAR");
        chainMineAlwaysShowNotification = config.getBoolean("usage-limits.chain-mine.notification.always-show", false);
        chainMineBossBarColor = config.getString("usage-limits.chain-mine.notification.boss-bar-color", "BLUE");
        chainMineBossBarTime = config.getInt("usage-limits.chain-mine.notification.boss-bar-time", 3);
        
        // 加载世界设置
        worldWhitelistMode = config.getBoolean("worlds.whitelist-mode", true);
        List<String> worldsList = config.getStringList("worlds.enabled-worlds");
        enabledWorlds.clear();
        enabledWorlds.addAll(worldsList);
        
        // 加载功能设置
        requireAxeForTreeChop = config.getBoolean("features.tree-chop.require-axe", true);
        clearLeaves = config.getBoolean("features.tree-chop.clear-leaves", true);
        mustChopBottom = config.getBoolean("features.tree-chop.must-chop-bottom", true);
        collectTreeDrops = config.getBoolean("features.tree-chop.collect-drops", true);
        requirePickaxeForChainMine = config.getBoolean("features.chain-mine.require-pickaxe", true);
        collectOreDrops = config.getBoolean("features.chain-mine.collect-drops", true);
        
        // 加载树木方块类型
        loadMaterialSet("blocks.tree-blocks", treeBlocks);
        
        // 加载树叶方块类型
        loadMaterialSet("blocks.leaf-blocks", leafBlocks);
        
        // 加载矿石方块类型
        loadMaterialSet("blocks.ore-blocks", oreBlocks);
        
        // 加载玩家数据
        loadPlayerData();
    }
    
    private void loadMaterialSet(String path, Set<Material> materialSet) {
        materialSet.clear();
        List<String> materialNames = config.getStringList(path);
        
        for (String name : materialNames) {
            try {
                Material material = Material.valueOf(name.toUpperCase());
                materialSet.add(material);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("无效的材料名称: " + name);
            }
        }
    }
    
    private void loadPlayerData() {
        File playerDataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!playerDataFolder.exists()) {
            playerDataFolder.mkdirs();
            return;
        }
        
        File[] playerFiles = playerDataFolder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (playerFiles == null) return;
        
        for (File file : playerFiles) {
            String fileName = file.getName();
            String uuidString = fileName.substring(0, fileName.length() - 4); // 移除 .yml
            
            try {
                UUID uuid = UUID.fromString(uuidString);
                FileConfiguration playerConfig = YamlConfiguration.loadConfiguration(file);
                
                boolean treeChopEnabled = playerConfig.getBoolean("tree-chop-enabled", true);
                boolean chainMineEnabled = playerConfig.getBoolean("chain-mine-enabled", true);
                int treeChopUsedToday = playerConfig.getInt("tree-chop-used-today", 0);
                int chainMineUsedToday = playerConfig.getInt("chain-mine-used-today", 0);
                long lastResetDay = playerConfig.getLong("last-reset-day", System.currentTimeMillis());
                
                PlayerData playerData = new PlayerData(uuid);
                playerData.setTreeChopEnabled(treeChopEnabled);
                playerData.setChainMineEnabled(chainMineEnabled);
                
                // 设置使用次数相关数据
                for (int i = 0; i < treeChopUsedToday; i++) {
                    playerData.incrementTreeChopUsage();
                }
                
                for (int i = 0; i < chainMineUsedToday; i++) {
                    playerData.incrementChainMineUsage();
                }
                
                playerData.setLastResetDay(lastResetDay);
                playerData.checkAndResetDailyUsage(); // 检查是否需要重置
                
                playerDataMap.put(uuid, playerData);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("无效的玩家UUID: " + uuidString);
            }
        }
    }
    
    public void saveConfig() {
        // 保存树木方块类型
        saveMaterialSet("blocks.tree-blocks", treeBlocks);
        
        // 保存树叶方块类型
        saveMaterialSet("blocks.leaf-blocks", leafBlocks);
        
        // 保存矿石方块类型
        saveMaterialSet("blocks.ore-blocks", oreBlocks);
        
        // 保存配置
        plugin.saveConfig();
        
        // 保存玩家数据
        savePlayerData();
    }
    
    private void saveMaterialSet(String path, Set<Material> materialSet) {
        List<String> materialNames = new ArrayList<>();
        for (Material material : materialSet) {
            materialNames.add(material.name());
        }
        config.set(path, materialNames);
    }
    
    private void savePlayerData() {
        File playerDataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!playerDataFolder.exists()) {
            playerDataFolder.mkdirs();
        }
        
        for (Map.Entry<UUID, PlayerData> entry : playerDataMap.entrySet()) {
            UUID uuid = entry.getKey();
            PlayerData playerData = entry.getValue();
            
            File playerFile = new File(playerDataFolder, uuid.toString() + ".yml");
            FileConfiguration playerConfig = YamlConfiguration.loadConfiguration(playerFile);
            
            playerConfig.set("tree-chop-enabled", playerData.isTreeChopEnabled());
            playerConfig.set("chain-mine-enabled", playerData.isChainMineEnabled());
            playerConfig.set("tree-chop-used-today", playerData.getTreeChopUsedToday());
            playerConfig.set("chain-mine-used-today", playerData.getChainMineUsedToday());
            playerConfig.set("last-reset-day", playerData.getLastResetDay());
            
            try {
                playerConfig.save(playerFile);
            } catch (IOException e) {
                plugin.getLogger().severe("无法保存玩家数据: " + uuid);
                e.printStackTrace();
            }
        }
    }
    
    public PlayerData getPlayerData(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerData playerData = playerDataMap.get(uuid);
        
        if (playerData == null) {
            playerData = new PlayerData(uuid);
            playerDataMap.put(uuid, playerData);
        }
        
        return playerData;
    }
    
    public Set<Material> getTreeBlocks() {
        return treeBlocks;
    }
    
    public Set<Material> getLeafBlocks() {
        return leafBlocks;
    }
    
    public Set<Material> getOreBlocks() {
        return oreBlocks;
    }
    
    public boolean isRequireAxeForTreeChop() {
        return requireAxeForTreeChop;
    }
    
    public boolean isClearLeaves() {
        return clearLeaves;
    }
    
    public boolean isMustChopBottom() {
        return mustChopBottom;
    }
    
    public boolean isCollectTreeDrops() {
        return collectTreeDrops;
    }
    
    public boolean isRequirePickaxeForChainMine() {
        return requirePickaxeForChainMine;
    }
    
    public boolean isCollectOreDrops() {
        return collectOreDrops;
    }
    
    public boolean isTreeChopLimitEnabled() {
        return treeChopLimitEnabled;
    }
    
    public int getDefaultTreeChopLimit() {
        return defaultTreeChopLimit;
    }
    
    public int getVipTreeChopLimit() {
        return vipTreeChopLimit;
    }
    
    public boolean isChainMineLimitEnabled() {
        return chainMineLimitEnabled;
    }
    
    public int getDefaultChainMineLimit() {
        return defaultChainMineLimit;
    }
    
    public int getVipChainMineLimit() {
        return vipChainMineLimit;
    }
    
    public String getTreeChopNotificationType() {
        return treeChopNotificationType;
    }
    
    public boolean isTreeChopAlwaysShowNotification() {
        return treeChopAlwaysShowNotification;
    }
    
    public String getTreeChopBossBarColor() {
        return treeChopBossBarColor;
    }
    
    public int getTreeChopBossBarTime() {
        return treeChopBossBarTime;
    }
    
    public String getChainMineNotificationType() {
        return chainMineNotificationType;
    }
    
    public boolean isChainMineAlwaysShowNotification() {
        return chainMineAlwaysShowNotification;
    }
    
    public String getChainMineBossBarColor() {
        return chainMineBossBarColor;
    }
    
    public int getChainMineBossBarTime() {
        return chainMineBossBarTime;
    }
    
    public boolean isWorldWhitelistMode() {
        return worldWhitelistMode;
    }
    
    public Set<String> getEnabledWorlds() {
        return enabledWorlds;
    }
    
    public boolean isWorldEnabled(String worldName) {
        boolean contains = enabledWorlds.contains(worldName);
        return worldWhitelistMode ? contains : !contains;
    }
    
    public void addEnabledWorld(String worldName) {
        enabledWorlds.add(worldName);
    }
    
    public void removeEnabledWorld(String worldName) {
        enabledWorlds.remove(worldName);
    }
    
    public void toggleWorldEnabled(String worldName) {
        if (enabledWorlds.contains(worldName)) {
            enabledWorlds.remove(worldName);
        } else {
            enabledWorlds.add(worldName);
        }
    }
    
    public void addTreeBlock(Material material) {
        treeBlocks.add(material);
    }
    
    public void removeTreeBlock(Material material) {
        treeBlocks.remove(material);
    }
    
    public void addOreBlock(Material material) {
        oreBlocks.add(material);
    }
    
    public void removeOreBlock(Material material) {
        oreBlocks.remove(material);
    }
    
    public int getNormalCooldown() {
        return normalCooldown;
    }
    
    public int getVipCooldown() {
        return vipCooldown;
    }
    
    public int getMaxTreeBlocks() {
        return maxTreeBlocks;
    }
    
    public int getMaxOreBlocks() {
        return maxOreBlocks;
    }
}