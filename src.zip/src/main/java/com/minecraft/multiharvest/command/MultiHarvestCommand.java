package com.minecraft.multiharvest.command;

import com.minecraft.multiharvest.MultiHarvest;
import com.minecraft.multiharvest.config.PlayerData;
import com.minecraft.multiharvest.util.PermissionUtils;
import com.minecraft.multiharvest.util.StatisticsManager.PlayerStats;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MultiHarvestCommand implements CommandExecutor, TabCompleter {
    
    private final MultiHarvest plugin;
    
    public MultiHarvestCommand(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(plugin.getLanguageManager().getMessageFromLang("general.command_player_only", "zh_CN"));
            return true;
        }
        
        Player player = (Player) sender;
        
        // 检查权限
        if (!PermissionUtils.canUse(player)) {
            player.sendMessage(plugin.getLanguageManager().getMessage("general.no_permission", player));
            return true;
        }
        
        // 无参数，打开主菜单
        if (args.length == 0) {
            plugin.getGuiManager().openMainGui(player);
            return true;
        }
        
        // 处理子命令
        switch (args[0].toLowerCase()) {
            case "help":
                sendHelpMessage(player);
                break;
                
            case "limit":
            case "limits":
                showLimits(player);
                break;
                
            case "toggle":
                if (args.length < 2) {
                    player.sendMessage(ChatColor.RED + "用法: /" + label + " toggle <tree|mine>");
                    return true;
                }
                
                PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
                
                if (args[1].equalsIgnoreCase("tree")) {
                    playerData.toggleTreeChop();
                    player.sendMessage(plugin.getLanguageManager().getMessage(
                            playerData.isTreeChopEnabled() ? "feature.tree_chop.enabled" : "feature.tree_chop.disabled", 
                            player));
                } else if (args[1].equalsIgnoreCase("mine")) {
                    playerData.toggleChainMine();
                    player.sendMessage(plugin.getLanguageManager().getMessage(
                            playerData.isChainMineEnabled() ? "feature.chain_mine.enabled" : "feature.chain_mine.disabled", 
                            player));
                } else {
                    player.sendMessage(plugin.getLanguageManager().getMessage("general.unknown_command", player, args[1]));
                }
                break;
                
            case "world":
                if (!PermissionUtils.isAdmin(player)) {
                    player.sendMessage(plugin.getLanguageManager().getMessage("general.no_permission", player));
                    return true;
                }
                
                if (args.length < 2) {
                    plugin.getGuiManager().openWorldConfigGui(player);
                    return true;
                }
                
                if (args[1].equalsIgnoreCase("list")) {
                    // 列出所有世界及其状态
                    player.sendMessage(ChatColor.GREEN + "===== 世界功能状态 =====");
                    boolean isWhitelistMode = plugin.getConfigManager().isWorldWhitelistMode();
                    player.sendMessage(ChatColor.YELLOW + "当前模式: " + 
                            (isWhitelistMode ? ChatColor.GREEN + "白名单" : ChatColor.RED + "黑名单"));
                    
                    for (org.bukkit.World world : player.getServer().getWorlds()) {
                        String worldName = world.getName();
                        boolean isEnabled = plugin.getConfigManager().isWorldEnabled(worldName);
                        player.sendMessage((isEnabled ? ChatColor.GREEN : ChatColor.RED) + worldName);
                    }
                    return true;
                } else if (args[1].equalsIgnoreCase("toggle")) {
                    if (args.length < 3) {
                        player.sendMessage(ChatColor.RED + "用法: /" + label + " world toggle <世界名>");
                        return true;
                    }
                    
                    String worldName = args[2];
                    org.bukkit.World world = player.getServer().getWorld(worldName);
                    
                    if (world == null) {
                        player.sendMessage(ChatColor.RED + "找不到世界: " + worldName);
                        return true;
                    }
                    
                    plugin.getConfigManager().toggleWorldEnabled(worldName);
                    boolean isEnabled = plugin.getConfigManager().isWorldEnabled(worldName);
                    
                    String status = isEnabled ? 
                            plugin.getLanguageManager().getMessage("feature.world.enabled", player) : 
                            plugin.getLanguageManager().getMessage("feature.world.disabled", player);
                    
                    player.sendMessage(plugin.getLanguageManager().getMessage("feature.world.toggle", player, worldName, status));
                    return true;
                } else if (args[1].equalsIgnoreCase("mode")) {
                    // 切换白名单/黑名单模式
                    boolean newMode = !plugin.getConfigManager().isWorldWhitelistMode();
                    plugin.getConfig().set("worlds.whitelist-mode", newMode);
                    plugin.saveConfig();
                    plugin.getConfigManager().loadConfig();
                    
                    player.sendMessage(ChatColor.GREEN + "世界模式已切换为: " + 
                            (newMode ? ChatColor.GREEN + "白名单" : ChatColor.RED + "黑名单"));
                    return true;
                } else {
                    player.sendMessage(ChatColor.RED + "未知的世界命令: " + args[1]);
                    player.sendMessage(ChatColor.YELLOW + "可用命令: list, toggle, mode");
                    return true;
                }
                
            case "stats":
                showPlayerStats(player);
                break;
                
            case "language":
            case "lang":
                if (args.length < 2) {
                    showAvailableLanguages(player);
                    return true;
                }
                
                String langCode = args[1].toLowerCase();
                plugin.getLanguageManager().setPlayerLanguage(player, langCode);
                // 消息已在setPlayerLanguage方法中发送
                break;
                
            case "reload":
                if (!PermissionUtils.isAdmin(player)) {
                    player.sendMessage(plugin.getLanguageManager().getMessage("general.no_permission", player));
                    return true;
                }
                
                plugin.reloadConfig();
                plugin.getLanguageManager().loadLanguages();
                plugin.getConfigManager().loadConfig();
                player.sendMessage(plugin.getLanguageManager().getMessage("general.reload_success", player));
                break;
                
            default:
                player.sendMessage(plugin.getLanguageManager().getMessage("general.unknown_command", player, args[0]));
                sendHelpMessage(player);
                break;
        }
        
        return true;
    }
    
    /**
     * 显示玩家的统计数据
     * @param player 玩家
     */
    private void showPlayerStats(Player player) {
        PlayerStats stats = plugin.getStatisticsManager().getPlayerStats(player);
        
        player.sendMessage(plugin.getLanguageManager().getMessage("stats.title", player));
        player.sendMessage(plugin.getLanguageManager().getMessage("stats.tree_total", player, stats.getTreeBlocksBroken()));
        player.sendMessage(plugin.getLanguageManager().getMessage("stats.ore_total", player, stats.getOreBlocksBroken()));
        
        // 显示树木类型详情
        if (!stats.getTreeBlocksByType().isEmpty()) {
            player.sendMessage(plugin.getLanguageManager().getMessage("stats.tree_detail", player));
            
            for (Map.Entry<Material, Integer> entry : stats.getTreeBlocksByType().entrySet()) {
                String materialName = formatMaterialName(entry.getKey().name());
                player.sendMessage(plugin.getLanguageManager().getMessage("stats.detail_format", player, materialName, entry.getValue()));
            }
        }
        
        // 显示矿石类型详情
        if (!stats.getOreBlocksByType().isEmpty()) {
            player.sendMessage(plugin.getLanguageManager().getMessage("stats.ore_detail", player));
            
            for (Map.Entry<Material, Integer> entry : stats.getOreBlocksByType().entrySet()) {
                String materialName = formatMaterialName(entry.getKey().name());
                player.sendMessage(plugin.getLanguageManager().getMessage("stats.detail_format", player, materialName, entry.getValue()));
            }
        }
    }
    
    /**
     * 显示可用的语言列表
     * @param player 玩家
     */
    private void showAvailableLanguages(Player player) {
        Map<String, String> languages = plugin.getLanguageManager().getAvailableLanguages();
        
        player.sendMessage(ChatColor.GOLD + "可用的语言:");
        for (Map.Entry<String, String> entry : languages.entrySet()) {
            player.sendMessage(ChatColor.YELLOW + "- " + entry.getKey() + ": " + ChatColor.WHITE + entry.getValue());
        }
        
        player.sendMessage(ChatColor.GOLD + "使用 /mh lang <语言代码> 来切换语言");
    }
    
    /**
     * 格式化材料名称
     * @param name 材料名称
     * @return 格式化后的名称
     */
    private String formatMaterialName(String name) {
        String[] parts = name.split("_");
        StringBuilder result = new StringBuilder();
        
        for (String part : parts) {
            if (part.length() > 0) {
                result.append(part.substring(0, 1).toUpperCase())
                      .append(part.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        
        return result.toString().trim();
    }
    
    /**
     * 显示玩家的使用次数限制
     * @param player 玩家
     */
    private void showLimits(Player player) {
        PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
        
        player.sendMessage(ChatColor.GREEN + "===== 使用次数限制 =====");
        
        // 显示自动砍树次数
        if (plugin.getConfigManager().isTreeChopLimitEnabled() && !PermissionUtils.hasUnlimitedTreeChop(player)) {
            int usedCount = playerData.getTreeChopUsedToday();
            int limit = PermissionUtils.isVip(player) ? 
                    plugin.getConfigManager().getVipTreeChopLimit() : 
                    plugin.getConfigManager().getDefaultTreeChopLimit();
            int remaining = limit - usedCount;
            
            player.sendMessage(plugin.getLanguageManager().getMessage("notification.tree_chop.remaining", player, remaining, limit));
        } else {
            player.sendMessage(ChatColor.GREEN + "自动砍树: " + ChatColor.GOLD + "无限制");
        }
        
        // 显示连锁挖矿次数
        if (plugin.getConfigManager().isChainMineLimitEnabled() && !PermissionUtils.hasUnlimitedChainMine(player)) {
            int usedCount = playerData.getChainMineUsedToday();
            int limit = PermissionUtils.isVip(player) ? 
                    plugin.getConfigManager().getVipChainMineLimit() : 
                    plugin.getConfigManager().getDefaultChainMineLimit();
            int remaining = limit - usedCount;
            
            player.sendMessage(plugin.getLanguageManager().getMessage("notification.chain_mine.remaining", player, remaining, limit));
        } else {
            player.sendMessage(ChatColor.BLUE + "连锁挖矿: " + ChatColor.GOLD + "无限制");
        }
    }
    
    private void sendHelpMessage(Player player) {
        player.sendMessage(ChatColor.GREEN + "===== MultiHarvest 帮助 =====");
        player.sendMessage(ChatColor.YELLOW + "/mh" + ChatColor.WHITE + " - 打开主菜单");
        player.sendMessage(ChatColor.YELLOW + "/mh toggle tree" + ChatColor.WHITE + " - 切换自动砍树功能");
        player.sendMessage(ChatColor.YELLOW + "/mh toggle mine" + ChatColor.WHITE + " - 切换连锁挖矿功能");
        player.sendMessage(ChatColor.YELLOW + "/mh stats" + ChatColor.WHITE + " - 查看你的采集统计");
        player.sendMessage(ChatColor.YELLOW + "/mh limits" + ChatColor.WHITE + " - 查看你的使用次数限制");
        player.sendMessage(ChatColor.YELLOW + "/mh lang <语言代码>" + ChatColor.WHITE + " - 切换语言");
        
        if (PermissionUtils.isAdmin(player)) {
            player.sendMessage(ChatColor.YELLOW + "/mh reload" + ChatColor.WHITE + " - 重新加载配置");
            player.sendMessage(ChatColor.YELLOW + "/mh world" + ChatColor.WHITE + " - 打开世界控制GUI");
            player.sendMessage(ChatColor.YELLOW + "/mh world list" + ChatColor.WHITE + " - 列出所有世界及其状态");
            player.sendMessage(ChatColor.YELLOW + "/mh world toggle <世界名>" + ChatColor.WHITE + " - 切换指定世界的功能状态");
            player.sendMessage(ChatColor.YELLOW + "/mh world mode" + ChatColor.WHITE + " - 切换白名单/黑名单模式");
        }
        
        player.sendMessage(ChatColor.GREEN + "提示: 潜行时可临时禁用功能");
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player)) {
            return new ArrayList<>();
        }
        
        Player player = (Player) sender;
        
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(Arrays.asList("help", "toggle", "stats", "lang", "limits"));
            
            if (PermissionUtils.isAdmin(player)) {
                completions.add("reload");
                completions.add("world");
            }
            
            return completions.stream()
                    .filter(s -> s.toLowerCase().startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("toggle")) {
                return Arrays.asList("tree", "mine").stream()
                        .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            } else if (args[0].equalsIgnoreCase("lang") || args[0].equalsIgnoreCase("language")) {
                return new ArrayList<>(plugin.getLanguageManager().getAvailableLanguages().keySet()).stream()
                        .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            } else if (args[0].equalsIgnoreCase("world") && PermissionUtils.isAdmin(player)) {
                return Arrays.asList("list", "toggle", "mode").stream()
                        .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("world") && args[1].equalsIgnoreCase("toggle") && PermissionUtils.isAdmin(player)) {
                return player.getServer().getWorlds().stream()
                        .map(org.bukkit.World::getName)
                        .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                        .collect(Collectors.toList());
            }
        }
        
        return new ArrayList<>();
    }
}