package com.minecraft.multiharvest.listener;

import com.minecraft.multiharvest.MultiHarvest;
import com.minecraft.multiharvest.config.PlayerData;
import com.minecraft.multiharvest.util.HarvestUtils;
import com.minecraft.multiharvest.util.PermissionUtils;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public class BlockBreakListener implements Listener {
    
    private final MultiHarvest plugin;
    private final HarvestUtils harvestUtils;
    
    public BlockBreakListener(MultiHarvest plugin) {
        this.plugin = plugin;
        this.harvestUtils = new HarvestUtils(plugin);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        
        // 检查玩家是否有使用权限
        if (!PermissionUtils.canUse(player)) {
            return;
        }
        
        // 检查玩家是否在潜行（潜行时禁用功能）
        if (player.isSneaking()) {
            return;
        }
        
        // 检查世界是否启用
        String worldName = block.getWorld().getName();
        if (!plugin.getConfigManager().isWorldEnabled(worldName)) {
            return;
        }
        
        // 获取玩家数据
        PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
        
        // 获取玩家手中的工具
        ItemStack tool = player.getInventory().getItemInMainHand();
        
        // 处理自动砍树
        if (playerData.isTreeChopEnabled() && PermissionUtils.canUseTreeChop(player) && 
                (plugin.getConfigManager().getTreeBlocks().contains(block.getType()))) {
            
            // 检查冷却时间
            if (!plugin.getCooldownUtils().canUseTreeChop(player)) {
                int remaining = plugin.getCooldownUtils().getRemainingTreeCooldown(player);
                player.sendMessage(plugin.getLanguageManager().getMessage("feature.tree_chop.cooldown", player, remaining));
                return;
            }
            
            // 检查使用次数限制
            if (plugin.getConfigManager().isTreeChopLimitEnabled() && !PermissionUtils.hasUnlimitedTreeChop(player)) {
                int usedToday = playerData.getTreeChopUsedToday();
                int limit = PermissionUtils.isVip(player) ? 
                        plugin.getConfigManager().getVipTreeChopLimit() : 
                        plugin.getConfigManager().getDefaultTreeChopLimit();
                
                if (usedToday >= limit) {
                    player.sendMessage(plugin.getLanguageManager().getMessage("feature.tree_chop.limit_reached", player, limit));
                    return;
                }
            }
            
            // 执行自动砍树
            int blocksDestroyed = harvestUtils.handleTreeChop(player, block);
            
            if (blocksDestroyed > 0) {
                // 设置冷却时间
                plugin.getCooldownUtils().setTreeCooldown(player);
                
                // 处理工具耐久度
                boolean toolBroken = plugin.getDurabilityManager().handleDurability(player, tool, blocksDestroyed);
                
                // 更新统计数据
                plugin.getStatisticsManager().addTreeBlocksBroken(player, block.getType(), blocksDestroyed);
                
                // 增加使用次数
                if (plugin.getConfigManager().isTreeChopLimitEnabled() && !PermissionUtils.hasUnlimitedTreeChop(player)) {
                    int usedCount = playerData.incrementTreeChopUsage();
                    int limit = PermissionUtils.isVip(player) ? 
                            plugin.getConfigManager().getVipTreeChopLimit() : 
                            plugin.getConfigManager().getDefaultTreeChopLimit();
                    
                    // 显示剩余次数通知
                    plugin.getNotificationManager().showTreeChopNotification(player, usedCount, limit);
                    
                    int remaining = limit - usedCount;
                    if (remaining <= 5 && remaining > 0) {
                        player.sendMessage(plugin.getLanguageManager().getMessage("feature.tree_chop.limit_warning", player, remaining));
                    }
                }
                
                // 播放效果
                if (plugin.getConfig().getBoolean("effects.sounds", true)) {
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.0f);
                }
                
                if (plugin.getConfig().getBoolean("effects.particles", true)) {
                    block.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, block.getLocation().add(0.5, 0.5, 0.5), 10, 0.5, 0.5, 0.5);
                }
                
                // 发送消息
                player.sendMessage(plugin.getLanguageManager().getMessage("feature.tree_chop.success", player, blocksDestroyed));
                
                // 如果工具损坏，发送提示
                if (toolBroken) {
                    player.sendMessage(plugin.getLanguageManager().getMessage("feature.tree_chop.tool_broken", player));
                }
            }
        }
        
        // 处理连锁挖矿
        else if (playerData.isChainMineEnabled() && PermissionUtils.canUseChainMine(player) && 
                plugin.getConfigManager().getOreBlocks().contains(block.getType())) {
            
            // 检查冷却时间
            if (!plugin.getCooldownUtils().canUseChainMine(player)) {
                int remaining = plugin.getCooldownUtils().getRemainingMineCooldown(player);
                player.sendMessage(plugin.getLanguageManager().getMessage("feature.chain_mine.cooldown", player, remaining));
                return;
            }
            
            // 检查使用次数限制
            if (plugin.getConfigManager().isChainMineLimitEnabled() && !PermissionUtils.hasUnlimitedChainMine(player)) {
                int usedToday = playerData.getChainMineUsedToday();
                int limit = PermissionUtils.isVip(player) ? 
                        plugin.getConfigManager().getVipChainMineLimit() : 
                        plugin.getConfigManager().getDefaultChainMineLimit();
                
                if (usedToday >= limit) {
                    player.sendMessage(plugin.getLanguageManager().getMessage("feature.chain_mine.limit_reached", player, limit));
                    return;
                }
            }
            
            // 执行连锁挖矿
            int blocksDestroyed = harvestUtils.handleChainMine(player, block);
            
            if (blocksDestroyed > 0) {
                // 设置冷却时间
                plugin.getCooldownUtils().setMineCooldown(player);
                
                // 处理工具耐久度
                boolean toolBroken = plugin.getDurabilityManager().handleDurability(player, tool, blocksDestroyed);
                
                // 更新统计数据
                plugin.getStatisticsManager().addOreBlocksBroken(player, block.getType(), blocksDestroyed);
                
                // 增加使用次数
                if (plugin.getConfigManager().isChainMineLimitEnabled() && !PermissionUtils.hasUnlimitedChainMine(player)) {
                    int usedCount = playerData.incrementChainMineUsage();
                    int limit = PermissionUtils.isVip(player) ? 
                            plugin.getConfigManager().getVipChainMineLimit() : 
                            plugin.getConfigManager().getDefaultChainMineLimit();
                    
                    // 显示剩余次数通知
                    plugin.getNotificationManager().showChainMineNotification(player, usedCount, limit);
                    
                    int remaining = limit - usedCount;
                    if (remaining <= 5 && remaining > 0) {
                        player.sendMessage(plugin.getLanguageManager().getMessage("feature.chain_mine.limit_warning", player, remaining));
                    }
                }
                
                // 播放效果
                if (plugin.getConfig().getBoolean("effects.sounds", true)) {
                    player.playSound(player.getLocation(), Sound.BLOCK_CHAIN_BREAK, 0.5f, 1.0f);
                }
                
                if (plugin.getConfig().getBoolean("effects.particles", true)) {
                    block.getWorld().spawnParticle(Particle.CRIT, block.getLocation().add(0.5, 0.5, 0.5), 10, 0.5, 0.5, 0.5);
                }
                
                // 发送消息
                player.sendMessage(plugin.getLanguageManager().getMessage("feature.chain_mine.success", player, blocksDestroyed));
                
                // 如果工具损坏，发送提示
                if (toolBroken) {
                    player.sendMessage(plugin.getLanguageManager().getMessage("feature.chain_mine.tool_broken", player));
                }
            }
        }
    }
}