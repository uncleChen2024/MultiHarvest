package com.minecraft.multiharvest.listener;

import com.minecraft.multiharvest.MultiHarvest;
import com.minecraft.multiharvest.config.PlayerData;
import com.minecraft.multiharvest.util.PermissionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 玩家活动监听器，用于处理玩家加入、退出等事件
 */
public class PlayerActivityListener implements Listener {
    
    private final MultiHarvest plugin;
    private final Map<UUID, BukkitTask> notificationTasks = new HashMap<>();
    
    public PlayerActivityListener(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // 检查并重置每日使用次数
        PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
        playerData.checkAndResetDailyUsage();
        
        // 如果配置了总是显示通知，则启动定时任务
        if (shouldShowTreeChopNotification(player) || shouldShowChainMineNotification(player)) {
            startNotificationTask(player);
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID playerUuid = player.getUniqueId();
        
        // 取消通知任务
        if (notificationTasks.containsKey(playerUuid)) {
            notificationTasks.get(playerUuid).cancel();
            notificationTasks.remove(playerUuid);
        }
        
        // 清理通知
        plugin.getNotificationManager().clearNotifications(player);
    }
    
    /**
     * 启动通知任务
     * @param player 玩家
     */
    private void startNotificationTask(Player player) {
        UUID playerUuid = player.getUniqueId();
        
        // 取消旧的任务
        if (notificationTasks.containsKey(playerUuid)) {
            notificationTasks.get(playerUuid).cancel();
        }
        
        // 创建新的任务，每30秒显示一次通知
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            
            PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
            
            // 显示自动砍树通知
            if (shouldShowTreeChopNotification(player)) {
                int usedCount = playerData.getTreeChopUsedToday();
                int limit = PermissionUtils.isVip(player) ? 
                        plugin.getConfigManager().getVipTreeChopLimit() : 
                        plugin.getConfigManager().getDefaultTreeChopLimit();
                
                plugin.getNotificationManager().showTreeChopNotification(player, usedCount, limit);
            }
            
            // 显示连锁挖矿通知
            if (shouldShowChainMineNotification(player)) {
                int usedCount = playerData.getChainMineUsedToday();
                int limit = PermissionUtils.isVip(player) ? 
                        plugin.getConfigManager().getVipChainMineLimit() : 
                        plugin.getConfigManager().getDefaultChainMineLimit();
                
                plugin.getNotificationManager().showChainMineNotification(player, usedCount, limit);
            }
        }, 100L, 600L); // 初始延迟5秒，之后每30秒执行一次
        
        notificationTasks.put(playerUuid, task);
    }
    
    /**
     * 检查是否应该显示自动砍树通知
     * @param player 玩家
     * @return 是否应该显示
     */
    private boolean shouldShowTreeChopNotification(Player player) {
        return plugin.getConfigManager().isTreeChopLimitEnabled() && 
               plugin.getConfigManager().isTreeChopAlwaysShowNotification() && 
               !PermissionUtils.hasUnlimitedTreeChop(player);
    }
    
    /**
     * 检查是否应该显示连锁挖矿通知
     * @param player 玩家
     * @return 是否应该显示
     */
    private boolean shouldShowChainMineNotification(Player player) {
        return plugin.getConfigManager().isChainMineLimitEnabled() && 
               plugin.getConfigManager().isChainMineAlwaysShowNotification() && 
               !PermissionUtils.hasUnlimitedChainMine(player);
    }
}