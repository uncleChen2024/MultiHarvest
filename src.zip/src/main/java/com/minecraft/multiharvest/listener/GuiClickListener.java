package com.minecraft.multiharvest.listener;

import com.minecraft.multiharvest.MultiHarvest;
import com.minecraft.multiharvest.config.PlayerData;
import com.minecraft.multiharvest.gui.GuiManager;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

public class GuiClickListener implements Listener {
    
    private final MultiHarvest plugin;
    
    public GuiClickListener(MultiHarvest plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals(GuiManager.MAIN_GUI_TITLE)) {
            handleMainGuiClick(event);
        } else if (event.getView().getTitle().equals(GuiManager.TREE_CONFIG_GUI_TITLE)) {
            handleTreeConfigGuiClick(event);
        } else if (event.getView().getTitle().equals(GuiManager.MINE_CONFIG_GUI_TITLE)) {
            handleMineConfigGuiClick(event);
        } else if (event.getView().getTitle().equals(GuiManager.WORLD_CONFIG_GUI_TITLE)) {
            handleWorldConfigGuiClick(event);
        }
    }
    
    private void handleMainGuiClick(InventoryClickEvent event) {
        event.setCancelled(true);
        
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        int slot = event.getRawSlot();
        
        if (slot == 11) {
            // 自动砍树开关
            PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
            playerData.toggleTreeChop();
            player.sendMessage(ChatColor.GREEN + "自动砍树功能已" + 
                    (playerData.isTreeChopEnabled() ? "启用" : "禁用"));
            plugin.getGuiManager().openMainGui(player);
        } else if (slot == 15) {
            // 连锁挖矿开关
            PlayerData playerData = plugin.getConfigManager().getPlayerData(player);
            playerData.toggleChainMine();
            player.sendMessage(ChatColor.GREEN + "连锁挖矿功能已" + 
                    (playerData.isChainMineEnabled() ? "启用" : "禁用"));
            plugin.getGuiManager().openMainGui(player);
        } else if (slot == 12) {
            // 自动砍树配置
            plugin.getGuiManager().openTreeConfigGui(player);
        } else if (slot == 13) {
            // 世界控制配置
            plugin.getGuiManager().openWorldConfigGui(player);
        } else if (slot == 14) {
            // 连锁挖矿配置
            plugin.getGuiManager().openMineConfigGui(player);
        }
    }
    
    private void handleTreeConfigGuiClick(InventoryClickEvent event) {
        event.setCancelled(true);
        
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        int slot = event.getRawSlot();
        
        if (slot == 0) {
            // 返回主菜单
            plugin.getGuiManager().openMainGui(player);
        } else if (slot == 8) {
            // 保存配置
            plugin.getGuiManager().saveTreeConfig(event.getInventory());
            player.sendMessage(ChatColor.GREEN + "自动砍树配置已保存！");
            plugin.getGuiManager().openMainGui(player);
        } else {
            // 处理方块点击
            plugin.getGuiManager().handleTreeConfigClick(player, slot, event.getInventory());
        }
    }
    
    
    private void handleMineConfigGuiClick(InventoryClickEvent event) {
        event.setCancelled(true);
        
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        int slot = event.getRawSlot();
        
        if (slot == 0) {
            // 返回主菜单
            plugin.getGuiManager().openMainGui(player);
        } else if (slot == 8) {
            // 保存配置
            plugin.getGuiManager().saveMineConfig(event.getInventory());
            player.sendMessage(ChatColor.GREEN + "连锁挖矿配置已保存！");
            plugin.getGuiManager().openMainGui(player);
        } else {
            // 处理方块点击
            plugin.getGuiManager().handleMineConfigClick(player, slot, event.getInventory());
        }
    }
    
    /**
     * 处理世界配置GUI的点击事件
     * @param event 点击事件
     */
    private void handleWorldConfigGuiClick(InventoryClickEvent event) {
        event.setCancelled(true);
        
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        int slot = event.getRawSlot();
        
        plugin.getGuiManager().handleWorldConfigClick(player, slot, event.getInventory());
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        String title = event.getView().getTitle();
        
        if (title.equals(GuiManager.TREE_CONFIG_GUI_TITLE) || title.equals(GuiManager.MINE_CONFIG_GUI_TITLE)) {
            // 自动保存配置
            if (title.equals(GuiManager.TREE_CONFIG_GUI_TITLE)) {
                plugin.getGuiManager().saveTreeConfig(event.getInventory());
            } else {
                plugin.getGuiManager().saveMineConfig(event.getInventory());
            }
        }
    }
}